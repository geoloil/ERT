rm *.o
rm iri
ls *.o
ls iri
