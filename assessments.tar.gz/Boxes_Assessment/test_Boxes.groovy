import g_ERT.*;

ContainerBox container = new ContainerBox (7, 3, 2);  // Inner container useFull sizes xSize, ySize, zSize
print   ("Container:");
println (container.toString());

println ()

Box box1 = new Box (4, 2, 2);  // xSize, ySize, zSize
print   ("A Box inside the container:");
println (box1.toString());  // printOut test OK
println ("Does it collide with container? " + box1.collides (container));

// Now shift the box to left 1 pixel, it will collide with the container

dx = 1; dy = 0; dz = 0;
box1.shift (dx, dy, dz);
print   ("The Box shifted:");
println (box1.toString());  // printOut test OK
println ("Does it collide with container? " + box1.collides (container));
println ("Can be fit inside container? " + container.canFitInside (box1));

         container . merge (box1);
println (container . toString());
println (container . getNBodiesInside());

// Now let's define a non trivial Shape3D body, similar to an L shape letter

Set<Point3D> secondPoints = new TreeSet<>();

secondPoints.add (new Point3D (1,2,1));
secondPoints.add (new Point3D (1,2,2));
secondPoints.add (new Point3D (1,3,2));
secondPoints.add (new Point3D (2,3,2));

Shape3D secondShape3D = new Shape3D (secondPoints);
dx = 0; dy = 0; dz = 0;
        secondShape3D . shift (dx,dy,dz);

container . merge (secondShape3D);
println (container . toString());
println (container . getNBodiesInside());

// Now let's define a non trivial Shape3D body, similar to an I shape letter

Set<Point3D> thirdPoints = new TreeSet<>();

thirdPoints.add (new Point3D (1,2,2));
thirdPoints.add (new Point3D (1,3,2));

Shape3D thirdShape3D = new Shape3D (thirdPoints);
dx = 5; dy = 0; dz = 0;
        thirdShape3D . shift (dx,dy,dz);

container . merge (thirdShape3D);
println (container . toString());
println (container . getNBodiesInside());
