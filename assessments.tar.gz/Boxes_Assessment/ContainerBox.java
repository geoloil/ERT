package g_ERT;

/**
  * Class with definition and methods (functions) for a large container box object,
  * it is like a Box, with the different is that it is empty inside, so boxes can
  * be arranged inside it.
  * @author  Oscar G. Gonzalez
  * @version $Revision: 1.9 $ $Date: 2022/07/30 16:25:01 $
  * @since   July 2022
  */
public final class ContainerBox extends Shape3D
{
// =======================================================================================================================
// FIELD VARIABLES
// =======================================================================================================================

/** Size in the X axis of the box */
private int xSize = 0;  // Initialized as void volume

/** Size in the Y axis of the box */
private int ySize = 0;  // Initialized as void volume

/** Size in the Z axis of the box */
private int zSize = 0;  // Initialized as void volume

/** The amount of bodies inside this container, it starts as a void container with no objects inside */
private int nBodiesInside = 0;

/** The proportion of un-occupied pixels in the container, it stars as 1.0 (100% void) */
private double emptyPixelsProportion = 1.0;

// =======================================================================================================================
// STATIC VARIABLES and CONSTANTS
// =======================================================================================================================
// CONSTRUCTORS
// =======================================================================================================================
/** Default Constructor */
public ContainerBox () {super();}  // Just a place-holder to reserve memory reference
// -----------------------------------------------------------------------------------------------------------------------
/**
  * Regular constructor to populate a discretized cartesian space Box
  * @param xSize The box size in the X axis, its usefull inner void cavity
  * @param ySize The box size in the Y axis, its usefull inner void cavity
  * @param zSize The box size in the Z axis, its usefull inner void cavity
  */
public ContainerBox (final int xSize, final int ySize, final int zSize)
{
super();

// Ensure that the box has a positive volume, other wise enforce a zero volume and dimensions

if ( (xSize <= 0) || (ySize <= 0) || (zSize <= 0) )
   {
   this.xSize = 0; this.ySize = 0; this.ySize = 0;
   return;
   }

for (int iz = 0; iz <= zSize+1; ++iz)  // Z is populated last, layer by layer
    {
    for (int iy = 0; iy <= ySize+1; ++iy)
        {
        for (int ix = 0; ix <= xSize+1; ++ix)  // X direction is the fastest loop, this is a standard
            {
            Point3D currentPoint3D = new Point3D (ix, iy, iz);

            // The container must have walls and its inner volume must void, so reject inner points inside, or accept only wall points
            // Inner points are between 1 to size-1

            boolean isPointInner = false;
            if ( (1 <= ix) && (ix <= xSize) && (1 <= iy) && (iy <= ySize) && (1 <= iz) && (iz <= zSize) )
               {isPointInner = true;}

            if (!isPointInner)  // It is a wall point
               {super.addPoint3D (currentPoint3D);}
            }
        }
    }

this.xSize = xSize;
this.ySize = ySize;
this.zSize = zSize;

} // End of constructor ContainerBox()
// =======================================================================================================================
// METHODS
// =======================================================================================================================
/**
  * This methods detects if a general Shape3D can be fit inside this container.
  * @param shape3D The general Shape3D to test if it can fit or not inside this container
  * @return true If the shape3D can be fit inside the container (even touching it is not allowed)
  */
public boolean canFitInside (final Shape3D shape3D)
{
shape3D.calculateExtremeIndices();

// Cases where the shape is fully outside this container, it might be very far away

final int shapeMinXindex = shape3D.getMinXindex();
final int shapeMinYindex = shape3D.getMinYindex();
final int shapeMinZindex = shape3D.getMinZindex();

final int shapeMaxXindex = shape3D.getMaxXindex();
final int shapeMaxYindex = shape3D.getMaxYindex();
final int shapeMaxZindex = shape3D.getMaxZindex();

if (shapeMinXindex < 1    ) {return (false);}
if (shapeMinYindex < 1    ) {return (false);}
if (shapeMinZindex < 1    ) {return (false);}

if (shapeMaxXindex > this.xSize) {return (false);}
if (shapeMaxYindex > this.ySize) {return (false);}
if (shapeMaxZindex > this.zSize) {return (false);}

// Not done yet, just in case, we must guarantee that an irregular shape does not collide with this container

ContainerBox newEmptyContainer = new ContainerBox (this.xSize, this.ySize, this.zSize);
if (newEmptyContainer.collides(shape3D))  {return (false);}

return (true);

}  // End of canFitInside()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method merges a shape3D into the container, that is, it adds the body shape3D if it can fit inside,
  * and there are no collisions with other objects already merged and packed inside.
  * @param shape3D The 3D body to be merged and embedded inside the container with already former bodies inside.
  */
public void merge (final Shape3D shape3D)
{
Monitor.whereAmI (true);
if (!this.canFitInside(shape3D)) {return;}    // And don't increase nBodiesInside, nor touch emptyPixelsProportion

// OK, the 3D body would fit into the original empty container. Now verify that wouldn't collide with occupied pixels

Monitor.whereAmI (true);
if (this.collides(shape3D)) {return;}  // And don't increase nBodiesInside, nor touch emptyPixelsProportion

// Good, now compute the pixels union, add nBodiesInside+1, and update emptyPixelsProportion

Monitor.whereAmI (true);
for (Point3D point3D : shape3D.getSet3D())
    {
    this.addPoint3D (point3D);
    }

++this.nBodiesInside;
//                                  OccupiedPixels                  OriginalVoidPixelVolume
this.emptyPixelsProportion = 1.0 - (this.countOfOccupiedPixels() / (xSize * ySize * zSize));

return;

}  // End of merge()
// =======================================================================================================================
// GET METHODS
// =======================================================================================================================
public int    getNBodiesInside()         {return (this.nBodiesInside);}
public double getEmptyPixelsProportion() {return (this.emptyPixelsProportion);}
// =======================================================================================================================
// SET METHODS
// =======================================================================================================================
// END OF METHODS
// =======================================================================================================================

// =======================================================================================================================
} // End of Class ContainerBox
