package g_ERT;

import java.util.*;

/**
  * This class specifies the definition and functionality of an unique 3D integer point,
  * we are so far handling semi-positive (0 to n)^3 integer numbers to model positive volume boxes.
  * @author  Oscar G. Gonzalez    
  * @version $Revision: 1.9 $ $Date: 2022/07/30 01:01:56 $
  * @since   July 2022
  */
public final class Point3D implements Comparable<Point3D>
{
// =======================================================================================================================
// FIELD VARIABLES
// =======================================================================================================================

/** Void value, an integer impossible to appear on this application project */
private final int voidValue = GlobalConstants.MISS_INT_VALUE;  // Copy from master constants for convenience

/** Coordinate on the X axis of the 3D point (x,y,x), it must be zero or larger */
private int x = this.voidValue;  //  -99999

/** Coordinate on the Y axis of the 3D point (x,y,x), it must be zero or larger */
private int y = this.voidValue;  //  -99999

/** Coordinate on the Y axis of the 3D point (x,y,x), it must be zero or larger */
private int z = this.voidValue;  //  -99999

/** Base of X to compute hashCode() */
private int baseX;

/** Base of Y to compute hashCode() */
private int baseY;

/** Base of Z to compute hashCode() */
private int baseZ;

/** Insertion order for the class to handle collections, 0,1,2,... */
private static long classInsertionOrder;

/** Insertion order for the object (class instance) to handle collections, 0,1,2,... */
private long insertionOrder;

/** True if at either x, y, or z are voidValue, false if all x,y,z components are admissible */
private boolean isEmpty = true;  // Start with a default pessimistic case

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
// PRIVATE STATIC CLASS VARIABLES
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

/** Default X base for hashCode() function, normally is enough, 11 bits = 2048 */
static private int defaultBaseX = 2048;

/** Default Y base for hashCode() function, normally is enough, 11 bits = 2048 */
static private int defaultBaseY = 2048;

/** Default Z base for hashCode() function, normally is enough, 10 bits = 1048 */
static private int defaultBaseZ = 1024;

/** true if the class has been instantiated, false if not instantiated yet */
static private boolean instantiated;

// =======================================================================================================================
// CONSTRUCTOR
// =======================================================================================================================
/**
  * Default constructor, after constructor and before instantiation you may call setHashCodeBase(),
  * if a previous instance has been created, the default bases for hashCode() are kept by default.
  */
public Point3D ()
{
this.x = GlobalConstants.MISS_INT_VALUE;
this.y = GlobalConstants.MISS_INT_VALUE;
this.z = GlobalConstants.MISS_INT_VALUE;

this.isEmpty = true;

if (!this.instantiated)  // Once the class is instantiated, do not allow hash base changes
   {
   this.baseX = this.defaultBaseX;
   this.baseY = this.defaultBaseY;
   this.baseZ = this.defaultBaseZ;
   }
}
// -------------------------------------------------------------------- 
/**
  * Constructor of Point3D from (x,y,z)
  * @param x Integer coordinate for X
  * @param y Integer coordinate for Y
  * @param z Integer coordinate for Z
  */
public Point3D (final int x, final int y, final int z)
{
if ((x==this.voidValue) || (y==this.voidValue) || (z==this.voidValue))
   {
   this.x = this.voidValue;
   this.y = this.voidValue;
   this.z = this.voidValue;

   this.isEmpty = true;
   }
else  // Then all x,y,z are not void, hence assign them.
   {
   this.x = x;
   this.y = y;
   this.z = z;

   this.isEmpty = false;

   this.instantiated = true;
   ++this.classInsertionOrder;
   this.insertionOrder = this.classInsertionOrder;
   }
}
// --------------------------------------------------------------------
/**
  * Constructs a Point3D from the vector p[0], p[1], p[2]
  * @param p vector p[0], p[1], p[2]; where p[0]=x, p[1]=y, p[2]=z.
  */
public Point3D (final int[] p)
{
if ((p[0]==this.voidValue) || (p[1]==this.voidValue) || (p[2]==this.voidValue))
   {
   this.x = this.voidValue;
   this.y = this.voidValue;
   this.z = this.voidValue;
   this.isEmpty = true;
   }
else  // Then all x,y,z are not void, hence assign them.
   {
   this.x = p[0];
   this.y = p[1];
   this.z = p[2];

   this.isEmpty = false;

   this.instantiated = true;
   ++this.classInsertionOrder;
   this.insertionOrder = this.classInsertionOrder;
   }
}
// =======================================================================================================================
// GET METHODS
// =======================================================================================================================
/**
  * Get method for the X coordinate this.x
  * @return The X coordinate this.x
  */
public int getX() {return (this.x);}
// -----------------------------------------------------------------------------------
/**
  * Get method for the Y coordinate this.y
  * @return The Y coordinate this.y
  */
public int getY() {return (this.y);}
// -----------------------------------------------------------------------------------
/**
  * Get method for the Z coordinate this.z
  * @return The Z coordinate this.z
  */
public int getZ() {return (this.z);}
// -----------------------------------------------------------------------------------
/**
  * Get method for baseX, only for maintenance and debugging
  * @return Base X for hash function
  */
public int getBaseX() {return (this.baseX);}
// -----------------------------------------------------------------------------------
/**
  * Get method for baseY, only for maintenance and debugging
  * @return Base Y for hash function
  */
public int getBaseY() {return (this.baseY);}
// -----------------------------------------------------------------------------------
/**
  * Get method for baseZ, only for maintenance and debugging
  * @return Base Z for hash function
  */
public int getBaseZ() {return (this.baseZ);}
// -----------------------------------------------------------------------------------
/**
  * Method that indicates if the class has been instantiated
  * @return true if the class has been instantiated, this.instantiated
  */
public boolean getInstantiated() {return (this.instantiated);}
// -----------------------------------------------------------------------------------
// /** Metodo que indica si el numero isEmpty */
public boolean getIsEmpty () {return (this.isEmpty);}
// =======================================================================================================================
// REGULAR METHODS
// =======================================================================================================================
/**
  * Metodo que estable las bases x,y,z para el calculo de hashCode().
  * <p>
  * El metodo mas adelante deberia o podria lanzar una excepcion si se
  * intenta setear la base del hashCode si la clase se ha instanciado,
  * pues eso indicaria una inconsistencia grave en el cambio del calculo
  * y los valores del hasCode(), afectando faltalmente incluso la igualdad
  * del hash code para objetos iguales, por el momento por seguridad
  * lo que esta implantado es que si la clase ya se ha instanciado,
  * no se permite cambiar las bases por consistencia, es decir un comportamiento
  * silencioso.
  * @param baseX baseX para el hashCode(), normalmente se usa baseX = nx
  * @param baseY baseY para el hashCode(), normalmente se usa baseY = ny
  * @param baseZ baseZ para el hashCode(), normalmente se usa baseZ = nz
  */
public void setHashCodeBase (final int baseX, final int baseY, final int baseZ)
{
if ( (!(this.baseX    *   this.baseY    *   this.baseZ == 0)) &&
     ( (this.baseX>0) && (this.baseY>0) && (this.baseZ>0) )   &&
     (! this.instantiated)
   )
   {
   this.baseX = baseX;
   this.baseY = baseY;
   this.baseZ = baseZ;
   }

}  // End of setHashCodeBase()
// -----------------------------------------------------------------------------------
/**
  * Este metodo hace Override de equals() con su su hashCode() acompanante,
  * solo se devuelve true si los puntos son realmente iguales coordenada a coordenada.
  * <p>
  * El parametro object es demasiado general, pero por el momento se queda asi.
  * @param object El punto entero a comparar
  * @return true si los objetos son iguales, false si son diferentes
  */
@Override public boolean equals (Object object)
{
boolean result = false;

if (!(object instanceof Point3D)) {result=false;}  // Solo deben permitirse objectos del mismo tipo.
else
   {
   Point3D  point3D = (Point3D)object;
   if (point3D != null)
      {
      if ( (this.x==point3D.x) && (this.y==point3D.y) && (this.z==point3D.z) )
           {result = true;}
      else {result=false;}
      }
   else {result=false;}
   }

return (result);
}
// -----------------------------------------------------------------------------------
/**
  * Este metodo hace Override de hashCode(), el procedimiento que he seguido es
  * bastante razonable para mallas de yacimientos, y en general para muchos
  * sistemas deja probabilidades de colision muy pequenas, (una colision se
  * define como dos objetos diferentes con el mismo hashCode()).
  * <p>
  * Para la mayoria de las aplicaciones de mallas en geoSciences, es suficientes
  * usar 11 bits para nx, 11 bits para ny y 10 bits para nz, esto produce un
  * total 11+11+10=32 bits que cabe perfectamente en los 4 bytes=32 bits del
  * integer de hash code. De no ser asi, las colisiones podrian ser problematicas
  * y en estos casos no se recomendaria usar esta clase, por ejemplo no creo
  * que aparezcan pronto mallas con mas de 2024 celdas en x,y o mas de 1024 en z.
  * <p>
  * Si se requieren nx,ny,nz mayores setear siempre explicitamente las bases de hashCode()
  * mediante el metodo setHashCodeBase() antes de cualquier instanciacion.
  */
@Override
public int hashCode ()
{
long    hashOut = -1;
int  intHashOut = -1;

if (this.baseX * this.baseY * this.baseZ == 0)
   {
   this.baseX = this.defaultBaseX;
   this.baseY = this.defaultBaseY;
   this.baseZ = this.defaultBaseZ;
   }

hashOut = this.z + baseZ*this.y + baseZ*baseY*this.x;

// Evitar un raro pero posible overflow:
if (hashOut > Integer.MAX_VALUE) {intHashOut = ((Long)hashOut).hashCode();}
else                             {intHashOut =  (int) hashOut;}

return (intHashOut);
}
// -----------------------------------------------------------------------------------
@Override
public int compareTo (Point3D  otherPoint) throws NullPointerException
{
final int BEFORE = -1;
final int EQUAL  =  0;
final int AFTER  =  1;

int comparison = EQUAL;

if (otherPoint==null)
   {
   throw new NullPointerException ("null PuntoEntero3D");
   }
else  // Objeto no nulo, continuar
   {
   if ( (this.x==otherPoint.x) && (this.y==otherPoint.y) && (this.z==otherPoint.z) )
      {
      comparison = EQUAL;
      }
   else
      {
      if (this.insertionOrder < otherPoint.insertionOrder)
         {
         comparison = BEFORE;
         }
      if (this.insertionOrder == otherPoint.insertionOrder)
         {
         comparison = EQUAL;
         }
      if (this.insertionOrder > otherPoint.insertionOrder)
         {
         comparison = AFTER;
         }
      }
   }

return (comparison);

}  // End of compareTo()
// -----------------------------------------------------------------------------------------------------------------------
@Override public String toString()
{
final String str = "(x,y,z) = " + String.valueOf(this.x) + ",\t" + String.valueOf(this.y) + ",\t" + String.valueOf(this.z) + "\n";

return (str);
}  // End of toString()
// =======================================================================================================================
// END OF METHODs
// =======================================================================================================================

}  // End of class Point3D
