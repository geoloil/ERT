package g_ERT;

import java.util.Date;

/**
  * Esta clase la he disenado para medir con precision el tiempo que toma
  * ejecutarse un codigo fuente.
  * Uso del cronometro: Se inicializa mediante: 
  * Monitor monitor = new Monitor (true)
  * se detiene el cronometro mediante:
  * monitor.deltaTime (true)
  * monitor.totalTime (true)
  * @author  Oscar G. Gonzalez
  * @version $Revision: 1.20 $ $Date: 2022/03/22 16:03:24 $
  * @since September 2012
  */
final public class Monitor
{
// ========================================================================================
// FIELD VARIABLES
// ========================================================================================
// CONSTRUCTOR
// ========================================================================================
// METHODS
// ========================================================================================
/**
  * Este es un metodo muy interesante, pues devuelve el numero de linea del
  * codigo fuente que lo ha llamado.
  * @return El numero de linea del codigo fuente que llamo este metodo.
  */
public static int getCurrentLineNumber()
{
int sourceLine = 0;

try    {sourceLine = Thread.currentThread().getStackTrace()[2].getLineNumber();}
catch  (Exception ex) {ex.printStackTrace();}

return (sourceLine);

}  // End of method getCurrentLineNumber()
// ------------------------------------------------------------------------------------------------------------------------------------
/**
  * Este metodo devuelve un String formateado como package.class.method(sourceCode:LineNumber),
  * por ejemplo g_gui.ListenerJTP.memModelFill(ListenerJTP.java:716)
  * @param threadLine El numero de linea del stack trace
  * @return Un String que indica el package, la clase, el method y el numero de linea donde fue llamado.
  */
static public String whereAmI (final int threadLine)
{
String output = "";

try   {output = Thread.currentThread().getStackTrace()[threadLine].toString();}
catch (Exception ex) {ex.printStackTrace();}

return (output.trim());

}  // End of whereAmI()
// ------------------------------------------------------------------------------------------------------------------------------------
/**
  * Este metodo estatico es mi reemplazamiento para el tracking tipo System.out.println()
  * @param isActive true imprime el tracking con el package, clase, numero de linea, y el mensaje del usuario, false sale silenciosamente.
  * @param message El mensaje a imprimir al System.out cuando isActive es true.
  */
static public void whereAmI (final boolean isActive, final Object message)
{
final String whoCalledMe = Monitor.whereAmI (3);  // La 3era. linea del stack refiere quien llamo esto.

final String output = whoCalledMe + " > " + String.valueOf(message);

if (isActive) {System.out.println (output);}
else          {return;}

}  // End of whereAmI()
// ------------------------------------------------------------------------------------------------------------------------------------
/**
  * Este metodo estatico es mi reemplazamiento para el tracking tipo System.out.println()
  * @param isActive true imprime el tracking con el package, clase, numero de linea, y el mensaje del usuario, false sale silenciosamente.
  */
static public void whereAmI (final boolean isActive)
{
if (isActive) {System.out.println (Monitor.whereAmI(3));}
else          {return;}

}  // End of whereAmI()
// ------------------------------------------------------------------------------------------------------------------------------------
/**
  * Este metodo es no mas que un uso simple de Thread.sleep() sin necesidad de envolverlo en try{}
  * @param waitMilliseconds El tiempo de espera en mili-segundos.
  */
static public void sleep (final int waitMilliseconds)
{try {Thread.sleep (waitMilliseconds);} catch (Exception e) {}}  // End of sleep()
// ========================================================================================
}  // End of class Monitor
