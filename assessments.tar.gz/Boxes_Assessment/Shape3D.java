package g_ERT;

import java.util.*;

/**
  * Class with definition and methods (functions) for a small input box object.
  * @author  Oscar G. Gonzalez
  * @version $Revision: 1.23 $ $Date: 2022/07/30 13:17:52 $
  * @since   July 2022
  */
public class Shape3D
{
// =======================================================================================================================
// FIELD VARIABLES
// =======================================================================================================================

/** Definition of an infinite number for this project */
private static final int INFINITE = 1_000_000_000;  // A large number, more than enough

/** A Shape3D is simply defined as a Set of 3D Points, that's all */
private Set<Point3D> set3D = new TreeSet<>();

/** The mimimum ix index for the 3D bounding box of its 3D Shape */
private int minXindex =  Shape3D.INFINITE;

/** The mimimum iy index for the 3D bounding box of its 3D Shape */
private int minYindex =  Shape3D.INFINITE;

/** The mimimum iz index for the 3D bounding box of its 3D Shape */
private int minZindex =  Shape3D.INFINITE;

/** The maximum ix index for the 3D bounding box of its 3D Shape */
private int maxXindex = -Shape3D.INFINITE;

/** The maximum ix index for the 3D bounding box of its 3D Shape */
private int maxYindex = -Shape3D.INFINITE;

/** The maximum ix index for the 3D bounding box of its 3D Shape */
private int maxZindex = -Shape3D.INFINITE;

// =======================================================================================================================
// STATIC VARIABLES and CONSTANTS
// =======================================================================================================================
// CONSTRUCTOR
// =======================================================================================================================
/** Default Constructor */
public Shape3D () {}  // Just a place-holder to reserve memory reference
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This constructor fully populates Shape3D for its collection of 3D points
  * @param points The collection of 3D points that populates this.set3D
  */
public Shape3D (final Set<Point3D> points)
{
for (Point3D point : points)
    {this.set3D.add (point);}

}  // End of Shape3D()
// =======================================================================================================================
// GET METHODS
// =======================================================================================================================
public Set<Point3D> getSet3D() {return (this.set3D);}

public int getMinXindex() {return (this.minXindex);}
public int getMinYindex() {return (this.minYindex);}
public int getMinZindex() {return (this.minZindex);}

public int getMaxXindex() {return (this.maxXindex);}
public int getMaxYindex() {return (this.maxYindex);}
public int getMaxZindex() {return (this.maxZindex);}
// =======================================================================================================================
// SET METHODS
// =======================================================================================================================
// REGULAR METHODS
// =======================================================================================================================
/**
  * This method counts the amount of occupied pixels, which is simple the size of this.set3D
  * @return The amount of occupied pixels.
  */
public int countOfOccupiedPixels()
{
return (this.set3D.size());

}  // End of countOfOccupiedPixels()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method adds a pont to the current set3D collection, as long as the point is not a repeated one.
  * @param point3D, the point to be added to the shape3D set of points, if the point already exists, it is not added.
  */
public void addPoint3D (final Point3D point3D)
{
this.set3D.add (point3D);

}  // End of addPoint3D()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method loops over all 3D points in the shape set to find the mins and maxs that enclose the tightest bounding box,
  * it internally sets minXindex, minYindex, minZindex, maxXindex, maxYindex, maxZindex after the loop.
  */
public void calculateExtremeIndices ()
{
// Later care of the exceptional cases, void, nulls, etc.

for (Point3D currentPoint3D : this.set3D)
    {
    int x = currentPoint3D.getX();
    int y = currentPoint3D.getY();
    int z = currentPoint3D.getZ();

    if (x < this.minXindex) {this.minXindex = x;}
    if (y < this.minYindex) {this.minYindex = y;}
    if (z < this.minZindex) {this.minZindex = z;}

    if (x > this.maxXindex) {this.maxXindex = x;}
    if (y > this.maxYindex) {this.maxYindex = y;}
    if (z > this.maxZindex) {this.maxZindex = z;}
    }

}  // End of calculateExtremeIndices()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * Just a quick but not dirty printOut, it prints the Set as ordered in Loop (Z), then Y, then X fastest
  */
public void printPoints()
{
for (Point3D currentPoint3D : this.set3D)
    {
    System.out.print (currentPoint3D.toString());
    }

}  // End of printPoints()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method return true if a point to be tested belongs to the Set of points of the Shape3D
  * @param point3D The point to be tested if it belongs to the Set of points of the Shape3D
  * @return true if the point to be tested belongs to the Set of points of the Shape3D
  */
public boolean contains (final Point3D point3D)
{
boolean found = false;

for (Point3D currentPoint3D : this.set3D)
    {
    if (currentPoint3D.equals(point3D)) {return (true);}
    }

return (found);

}  // End of contains()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method detects if this Shape3D collides (not void intersection) with other Shape3D
  * @param otherShape3D The otherShape3D to be tested if collides or not with this Shape3D
  * @return true if the otherShape3D collides (not void intersection) with this Shape3D
  */
public boolean collides (final Shape3D otherShape3D)
{
boolean collision = false;

for (Point3D thisPoint3D : this.set3D)
    {
    for (Point3D otherPoint3D : otherShape3D.getSet3D())
        {
        if (thisPoint3D.equals (otherPoint3D)) {return (true);}  // At least one point of collision, enough
        }
    }

return (collision);

}  // End of collide()
// -----------------------------------------------------------------------------------------------------------------------
/**
  * This method shits a Shape3D in three dimensions.
  * @param shiftX Amount of shifting on the X axis, can be negative to positive
  * @param shiftY Amount of shifting on the Y axis, can be negative to positive
  * @param shiftZ Amount of shifting on the Z axis, can be negative to positive
  */
public void shift (final int shiftX, final int shiftY, final int shiftZ)
{
// Algorithm, copy this.set3D into a new Set, then shift the elements, then clear this.set3D and repopulate without
// loosing the memory reference.

Set<Point3D> shiftedSet = new TreeSet<> ();

for (Point3D originalPoint : this.set3D)
    {
    int shiftedXcoor = shiftX + originalPoint.getX();
    int shiftedYcoor = shiftY + originalPoint.getY();
    int shiftedZcoor = shiftZ + originalPoint.getZ();

    Point3D shiftedPoint = new Point3D (shiftedXcoor, shiftedYcoor, shiftedZcoor);
    shiftedSet.add (shiftedPoint);
    }

this.set3D.clear();  // Remove all original 3D points without deleting the set memory reference address

for (Point3D shiftedPoint : shiftedSet)
    {
    this.set3D.add (shiftedPoint);
    }

shiftedSet = null;  // Now it is perfectly safe to empty the memory reference address

}  // End of shift()
// =======================================================================================================================
// END OF REGULAR METHODS
// =======================================================================================================================
// OVERRIDE METHODS
// =======================================================================================================================
/**
  * This method provides a printOut of the 3D Shape as a string, layer by layer
  * @return A printOut of the 3D Shape as a string, layer by layer.
  */
@Override public String toString()
{
calculateExtremeIndices();  // Is OK

Monitor.whereAmI (false, this.maxZindex);
Monitor.whereAmI (false, this.maxYindex);
Monitor.whereAmI (false, this.maxXindex);

String str = "";

for (int iz = 0; iz <= this.maxZindex; ++iz)  // Start from the first layer iz=0
    {
    if (iz < this.minZindex)  // Carriage return and continue to the next layer
       {
    // str += "\n";  // Not now yet
       continue;
       }

    // OK. We are at the first layer with data or beyond

    str += "\nLayer " + String.valueOf(iz).trim() + ":\n";

    for (int iy = 0; iy <= this.maxYindex; ++iy)
        {
        if (iy < this.minYindex)  // Carriage return and continue to the next Y row
           {
           str += "\n";
           continue;
           }

        for (int ix = 0; ix <= this.maxXindex; ++ix)  // The fastest loop
            {
            Point3D currentPoint3D = new Point3D (ix, iy, iz);
            Monitor.whereAmI (false, currentPoint3D);

         // Java built set operation is not working properly. Why?
         // if (this.set3D.contains (currentPoint3D)) {str += "*";}
         // else                                      {str += "-";}

            // Oscar's manual Set operation is working OK.
            if (this.contains (currentPoint3D)) {str += "*";}
            else                                {str += " ";}
            }
        str += "\n";  // Carriage return and continue to next Y row
        }
    }

return (str);

}  // End of toString()
// =======================================================================================================================

// =======================================================================================================================
} // End of Class Shape3D
