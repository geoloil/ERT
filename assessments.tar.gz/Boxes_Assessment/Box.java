package g_ERT;

/**
  * Class with definition and methods (functions) for a small input box object,
  * these boxes don't have a lid to open then, so they are like solids without void spaces inside,
  * so all its "pixels" are set as "on"
  * @author  Oscar G. Gonzalez
  * @version $Revision: 1.10 $ $Date: 2022/07/30 02:31:40 $
  * @since   July 2022
  */
public final class Box extends Shape3D
{
// =======================================================================================================================
// FIELD VARIABLES
// =======================================================================================================================

/** Size in the X axis of the box */
private int xSize = 0;  // Initialized as void volume

/** Size in the Y axis of the box */
private int ySize = 0;  // Initialized as void volume

/** Size in the Z axis of the box */
private int zSize = 0;  // Initialized as void volume

// =======================================================================================================================
// STATIC VARIABLES and CONSTANTS
// =======================================================================================================================
// CONSTRUCTORS
// =======================================================================================================================
/** Default Constructor */
public Box () {super();}  // Just a place-holder to reserve memory reference
// -----------------------------------------------------------------------------------------------------------------------
/**
  * Regular constructor to populate a discretized cartesian space Box
  * @param xSize The box size in the X axis
  * @param ySize The box size in the Y axis
  * @param zSize The box size in the Z axis
  */
public Box (final int xSize, final int ySize, final int zSize)
{
super();

// Ensure that the box has a positive volume, other wise enforce a zero volume and dimensions

if ( (xSize <= 0) || (ySize <= 0) || (zSize <= 0) )
   {
   this.xSize = 0; this.ySize = 0; this.ySize = 0;
   return;
   }

// OK, for now on, it is guaranteed that the volume is strictly >= 1 pixel^3
// If a size is 1, then populate only element coordinate zero:  (loop till size - 1)

for (int iz = 1; iz <= zSize; ++iz)  // Z is populated last, layer by layer
    {
    for (int iy = 1; iy <= ySize; ++iy)
        {
        for (int ix = 1; ix <= xSize; ++ix)  // X direction is the fastest loop, this is a standard
            {
            Point3D currentPoint3D = new Point3D (ix, iy, iz);
            super.addPoint3D (currentPoint3D);  // Add all points to the box, which is also a shape3D solid without holes in this case
            Monitor.whereAmI (false, "here");  // Is OK.
            }
        }
    }

} // End of constructor Box()
// =======================================================================================================================
// METHODS
// =======================================================================================================================
// =======================================================================================================================
// GET METHODS
// =======================================================================================================================
// =======================================================================================================================
// SET METHODS
// =======================================================================================================================
// END OF METHODS
// =======================================================================================================================

// =======================================================================================================================
} // End of Class Box
