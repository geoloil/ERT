#!/bin/bash

declare -i cum_errors=0
declare -i error=0

# Do no obfuscate by omission. To obfuscate, just use a parameter, like bash compile_ERT.sh OBF

echo ""
if [ $# -gt 0 ]
then
   echo "Compiling with obfuscation. Please wait..."
else
   echo "Compiling without obfuscation. Please wait..."
fi
echo ""

#*** FUNCTIONS ******************************************************
# -------------------------------------------------------------------
function pr_error
{
error=$?
if [ $error -gt 0 ]; then
   echo "===> ERROR CODE : $error <==="
   echo ""
   exit $error
   error=1
fi
let cum_errors=$cum_errors+$error
}
# -------------------------------------------------------------------
function tot_errors
{
echo ""
if [ $cum_errors -gt 0 ]
then
   echo "===> $cum_errors ERRORS <==="
else
   echo "===> 0 Errors <==="
fi

return $cum_errors
}
# -------------------------------------------------------------------
#*** End Functions **************************************************

# -------------------------------------------------------------------
# Delete recursively all regular files, keep only directories

if [ ! -d "../Class" ]; then
   mkdir ../Class
fi
cd ../Class
find . -type f | xargs rm  # Make sure you have all very latest versions only.

# -------------------------------------------------------------------------------------

# Work in the Sources directory.
cd ../Sources

# Compilacion masiva completa desde cero, todas las clases desde directorio Sources
groovyc -j -FXlint:unchecked  @java_groovy_ERT.lst
pr_error

mv g_ERT/*.class  ./../Class/g_ERT/  
mv *.class        ./../Class/

# --------------------------------------------------------------
# JAR building
# --------------------------------------------------------------
jar_file_dev=ERT_dev.jar  # ERT Jar on development

# Remove possible old versions of the jar
if [ -e $jar_file_dev ]; then
   rm $jar_file_dev # Borrar cualquier version vieja.
   pr_error
fi

# Document with javadoc.
ls *.html | egrep -v _help | xargs rm

javadoc -stylesheetfile javadoc.css -author -version -windowtitle "ERT" -doctitle "ERT API Docs" g_ERT

# ===========================================================================================================================
# Work now with the compiled binary classes
cd ../Class
# --------------------------------------------------------------------

# All these resources come from Sources
cp  ./../Sources/ERT.mf  .

# classpath on running time
pr_error

echo ""

jar -cmf ERT.mf $jar_file_dev ERT.class g_ERT

cp $jar_file_dev ../Sources/.

if [ $# -gt 0 ]
then
    cp $jar_file ../Sources/.
fi

# -------------------------------------------------------------------------------------------------------------------------
# Finally come back to Sources

cd ../Sources

# Litle help to run compiled JAR:

if [ $cum_errors -eq 0 ]
then
   echo ""
   echo "+------------------------------------------------------------+"
   echo "|  For a default run type :  java -jar ERT_dev.jar &         |"
   echo "|  To use a heap of 5 giga: java -jar -Xmx5g ERT_dev.jar &   |"
   echo "+------------------------------------------------------------+"
fi

tot_errors
