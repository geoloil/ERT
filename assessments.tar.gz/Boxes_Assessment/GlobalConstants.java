package g_ERT;

/**
  * This interface provides common constants for ERT classes.
  * @author  Oscar G. Gonzalez
  * @version $Revision: 1.1 $ $Date: 2022/07/28 19:18:00 $
  * @since   July 2022
  */
public interface GlobalConstants
{
// =======================================================================================
// FIELD VARIABLES
// =======================================================================================

/** Default symbolic value for a missed or a void integer */
public final int MISS_INT_VALUE = -99999;  // It is very unlikealy to handle this number in real problems

// ==========================================================================================

}  // End of Interface GlobalConstants
