<html lang="en">

<head>
      <title>
      ERT employment assessment for Oscar Gonzalez
      </title>

      <link rel="icon"          href="https://geoloil.com/favicon.ico" type="image/x-icon"/>
      <link rel="shortcut icon" href="https://geoloil.com/favicon.ico" type="image/x-icon"/>
      <meta name="thumbnail"    content="Images/webMainPage.png">

      <meta name="description" content="ERT employment assessment for Oscar Gonzalez">
      <meta name="keywords"    content="ERT, Oscar Gonzalez, Assessment">
      <meta name="robots"      content="noindex, nofollow">
      <meta name="viewport"    content="width=device-width, initial-scale=1">

      <? include 'header-Responsive.html'; ?>

      <link rel="canonical" href="https://geoloil.com/ERT.php"/>
</head>

<body>

<div class="leftSideBar" style="height: auto; background-color: #FFFFFF;">
    <? include 'leftBar-Responsive.html'; ?>
</div>

<div class="content">

<h2>
<img class="w0454" src="Images/GeolOil_PetrSoftLogAnalysis.gif" alt="GeolOil Petrophysics Software and Well Logging Analysis">
</h2>

<br><br>

<h1>
ERT Assement JavaScript: Basic HTML5/CSS/JavaScript development
</h1>

<br>

<h2>
<img class="w1019" src="Images/Assessment_JavaScript.png" alt="Assessment test">
</h2>

<br>

<h2>This is the exercise: Enter a real number from 0 to 100</h2>

<div class="listb">

<table border="0" cellpadding="1" cellspacing="4" align="center">
        <tr>
            <td align=right><samp>x=</samp></td>
            <td><input type="text" name="name" id="numericalBox" size="20" maxlength="25"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=center>
            <input type="button" id="process" value="Process">
            </td>
        </tr>
</table>

<p class="output" id="out11">This is a test</p>


<br><br>

<table border="0" cellpadding="1" cellspacing="4" align="center">

        <tr>
            <td align=right><samp>orig 1</samp></td>
            <td><input type="text" name="email" id="orig1" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 1</samp></td>
            <td><input type="text" name="company" id="ret1" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 2</samp></td>
            <td><input type="text" name="email" id="orig2" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 2</samp></td>
            <td><input type="text" name="company" id="ret2" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 3</samp></td>
            <td><input type="text" name="email" id="orig3" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 3</samp></td>
            <td><input type="text" name="company" id="ret3" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 4</samp></td>
            <td><input type="text" name="email" id="orig4" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 4</samp></td>
            <td><input type="text" name="company" id="ret4" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 5</samp></td>
            <td><input type="text" name="email" id="orig5" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 5</samp></td>
            <td><input type="text" name="company" id="ret5" size="12" maxlength="12"
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 6</samp></td>
            <td><input type=text name=email id=orig6 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 6</samp></td>
            <td><input type=text name=company id=ret6 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 7</samp></td>
            <td><input type=text name=email id=orig7 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 7</samp></td>
            <td><input type=text name=company id=ret7 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 8</samp></td>
            <td><input type=text name=email id=orig8 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 8</samp></td>
            <td><input type=text name=company id=ret8 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 9</samp></td>
            <td><input type=text name=email id=orig9 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 9</samp></td>
            <td><input type=text name=company id=ret9 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

        <tr>
            <td align=right><samp>orig 10</samp></td>
            <td><input type=text name=email id=orig10 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>

            <td align=right><samp>ret 10</samp></td>
            <td><input type=text name=company id=ret10 size=12 maxlength=12
                       style="font-family: verdana, fantasy, serif, monospace, sans serif, times, courier, fixed, helvetica;
                              font-size: 12px;
                              font-style:  normal;
                              font-weight: normal;
                              color: #000000;"
                              >
            </td>
        </tr>

</table>

</div> <!-- <div> -->

<script>
        const origBox = document.getElementByID('numericalBox');
        const execute = document.getElementByID('process');
        const orig1   = document.getElementByID('orig1');
        const parag   = document.getElementByID('out11');

        function f1() {
                      parag.innerHTML = origBox.value;
                      parag.innerHTML = 'hola';
                      orig1.innerHTML = origBox.value;
        }

        function validation() {
                              var reaVal = document.getElementByID('numericalBox');
                              console.log (reaVal);
                              if (isNaN(reaVal)) {return false}
                              else {
                              document.getElementByID('numericalBox').innerHTML = "No hope";
                              return true;
                              }
        }
        
        execute.addEventListener('click', f1());

</script>


<br>
<? include 'allPagesBanner-Responsive.html'; ?>

<div class="text">

<br>

<p class="center">
<a target="external" href="https://www.google.com/search?q=geoloil%20LLC#lrd=0x876b8fa2acae4f97:0x290163e9d08e090d,1,,,">
4.6 <span style="text-decoration:none; color: GoldenRod;">&#9733;&#9733;&#9733;&#9733;&#9734;</span> &nbsp;on Google
</a>
</p>
               <table align="center"cellpadding="5" cellspacing="0">
                      <tr>
                          <td valign=middle align="center">
                              <a href="downloads.php">
                              <img src="Images/downloads_arrow_rounded.png" class="imageMenuIndex imgShadow" align="center" alt="Binary numbers">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="downloads.php">Downloads</a></i></b></samp>
                              </p>
                          </td>

                          <td valign=middle align="center">
                              <a href="products.php">
                              <img src="Images/products_edt_rounded.png" class="imageMenuIndex imgShadow" align="center" alt="CDs">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="products.php">Products</a></i></b></samp>
                              </p>
                          </td>

                          <td valign=middle align="center">
                              <a href="Petrophysical-Data-Processing-and-Interpretation.php">
                              <img src="Images/geoloil-services-150x100.png" class="imageMenuIndex imgShadow" align="center" alt="Services">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="Petrophysical-Data-Processing-and-Interpretation.php">Consulting</a></i></b></samp>
                              </p>
                          </td>
                      </tr>
               </table>

               <table align="center">
                      <tr>
                          <td valign="top">
                              <img class="w0048" src="Images/windows_icon.png" border="0" width="48" height="48" align="middle" alt="Windows Operating System Icon"></a>
                              <img class="w0048" src="Images/apple_icon.png"   border="0" width="48" height="48" align="middle" alt="Apple MacOS Operating System Icon"></a>
                              <img class="w0048" src="Images/linux_icon.png"   border="0" width="48" height="48" align="middle" alt="Linux Operating System Icon"></a>
                          </td>
                      </tr>
               </table>

               <div class="listb">
               <p class="center">
               Latest stable version <a href="releases.php">March 2022</a>
               </p>

               <br>

               <p class="center">
               GeolOil runs on Windows, MacOS, and Linux.&nbsp;&nbsp;&nbsp;Compare it to Schlumberger's
               <a href="Techlog-versus-GeolOil.php">TechLog</a>
               </p>
               </div>

<br>

               <table align="center"cellpadding="5" cellspacing="0">
                      <tr>
                          <td valign=middle align="center">
                              <a href="petrophysics-training.php">
                              <img src="Images/virtual-learning-2people-150x100px.png" class="imageMenuIndex imgShadow" align="center" alt="Petrophysics Training">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="petrophysics-training.php">Training</a></i></b></samp>
                              </p>
                          </td>

                          <td valign=middle align="center">
                              <a href="petrophysicsManual.php">
                              <img src="Images/cookbook_web_rounded.png" class="imageMenuIndex imgShadow" align="center" alt="Petrophysical Recipes Cookbook">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="petrophysicsManual.php">HandBook</a></i></b></samp>
                              </p>
                          </td>

                          <td valign=middle align="center">
                              <a href="tutorials.php">
                              <img src="Images/owl_video_rounded.png" class="imageMenuIndex imgShadow" align="center" alt="Petrophysics Educative Videos">
                              </a>
                              <p class="center">
                              <samp><b><i><a href="tutorials.php">Videos</a></i></b></samp>
                              </p>
                          </td>
                      </tr>
               </table>

<br>

<table width="100%">
<tr>
    <td align="left">
        <samp><b><i>TESTIMONIALS&darr;</i></b></samp>
    </td>

    <td align="center">
        <samp><i><a href="testimonials.php">All reviews&rarr;</a></i></samp>
    </td>

    <td align="right">
        <samp><i><a target="external" href="https://www.google.com/search?q=geoloil&source=hp&ei=v-aPYtK0LsKntAbHjL2ACg&iflsig=AJiK0e8AAAAAYo_0z0Ih3zXOqND9ViJKcYooT5Z2Zkh4&ved=0ahUKEwiSkM6VhP73AhXCE80KHUdGD6AQ4dUDCAk&uact=5&oq=geoloil&gs_lcp=Cgdnd3Mtd2l6EAMyBQgAEIAEMgYIABAeEAo6DgguEI8BEOoCEIwDEOUCOg4IABCPARDqAhCMAxDlAjoLCAAQgAQQsQMQgwE6EQguEIAEELEDEIMBEMcBENEDOggIABCABBCxAzoRCC4QgAQQsQMQgwEQxwEQowI6CwguEIAEELEDEIMBOggILhCABBCxAzoICC4QgAQQ1AI6BQguEIAEOgsILhCABBCxAxDUAjoOCAAQgAQQsQMQgwEQyQM6BAgAEAo6BwgAELEDEAo6CggAELEDEIMBEAo6CggAELEDEMkDEAo6BQgAEJIDUKIdWOAnYM8saAFwAHgAgAGNAYgB2QWSAQMzLjSYAQCgAQGwAQo&sclient=gws-wiz#lrd=0x876b8fa2acae4f97:0x290163e9d08e090d,1,,,">Google reviews&rarr;</a></i></samp>
</tr>
</table>

<p class="left">
<div style="border:0px; border-style:solid; border-color:#000000; margin: 0rem; padding: 0.5rem; background-color: #E5E7E7;">
<div class="testimonial">

2022 April: "I'm a huge fan of GeolOil. It is user friendly, the help buttons are awesome, the videos are an excellent resource.
Some of the stuff sort of comes naturally to me as I've used several types of software throughout my career in the O&G.
Overall, this software is GREAT!"
<br><br><code>Hailey Smith.</code>
<a target="external" rel="follow" href="https://www.tamuk.edu/">
Texas A&amp;M University</a>, USA.∎

<hr width="100%">

2021 August: "I am sincerely grateful that GeolOil is at my fingertips."
<br><br><code>Matthew Gerard.</code> Expert Petrophysicist Consultant with 35 years of experience, Texas, USA.∎

<hr width="100%">

2021 March: "I must say, the GeolOil software has been an absolute god send to me as it's enabled me to pick up extra work,
work from home, and be self sufficient, so I greatly appreciate the support and the program."
<br><br><code>Joel Corcoran.</code> Senior Geoscientist. Consultant, England, UK.∎

<hr width="100%">

2020 May: "I do enjoy the detailed workflow for determining various attributes".
<br><br><code>Jason Currie. PG., MS.</code> CEO and President of Point Bar Energy LLC, Oklahoma City, OK. USA.∎

<hr width="100%">

2019 September: "I have been using GeolOil for over 5 years.  It is a great tool for doing
petrophysical analysis with the ability to do several complex work-flows in a
sequential format that is easy to setup and runs very quickly.  The log displays
are very good and it is easy to edit, shift, manipulate, and manage log curves..."
<a href="testimonials.php">Read more</a>.
<br><br><code>Brian Black.</code> Owner and Geologist. Black Petroleum Resources, LLC. Utah, USA.∎

<hr width="100%">

2017 June: "GeolOil has been great so far. I was glad to have found a package that runs fine on MacOS.
I haven't yet fully utilized a lot of the software's capabilities, but I have
uploaded tons of LAS files from a prior petrophysical analysis. It is easy to learn the
basics and display the data in a visually impactful way"
<a href="testimonials.php">Read more</a>.
<br><br><code>Michael Putnam.</code> Independent Geoscientist. Texas, USA.∎

<hr width="100%">

2016 March: "GeolOil hits home on major areas that I look for in good software:
1) Platform independence. I use GeolOil in both MacOS, Windows and Linux, and have no issues.
2) The graphical interface and user experience truly is elegant.
   It is very easy to navigate, has natural flow, and good typesetting.
   I felt comfortable in the package less than ten minutes from when I first installed.
   The "major" commercial packages don't even compare or come close
   to ease of use or graphic design...
"
<a href="testimonials.php">Read more</a>.
<br><br><code>Evan Patrick Egenolf.</code> Assistant Research Scientist.
<a target="external" rel="nofollow" href="http://www.uwyo.edu/cmi/">
University of Wyoming</a>, 
Laramie, Wyoming, USA.∎

<hr width="100%">

2015 October: "GeolOil is a versatile and intuitive tool for characterizing and
analyzing geologic data. I have used it to input large amounts of stratigraphic
data, and the program easily defines markers, formations, zones, and multiple sub-zones..."
<a href="testimonials.php">Read more</a>.
<br><br><code>Chris Peterson.</code> Senior Geologist.  Magellan Petroleum Corporation, 
Colorado, USA.∎

<hr width="100%">

2015 February: "We have been using GeolOil since 2011.
This package captures key geological settings of the reservoir. We have imported its
results into the simulators Eclipse, Tempest-More,  and CMG-STARS with the highest quality.
..." <a href="testimonials.php">Read more</a>.
<br><br><code>Mahmood Ahmadi, PhD.</code> Vice-President of
<a target="external" rel="follow" href="http://www.mi3pe.com/">MI3 Petroleum Engineering</a>, 
Colorado, USA.∎

<hr width="100%">

2014 July: "I have been using the <a href="logLAS.php">LAS Displayer</a> module of GeolOil for
some months now. It has added tremendous value to my daily work because it allows
a quick and neat access to critical petrophysical data, so I can devote more time
analyzing information and making decisions regarding the reservoir simulation models
I’m building. ..." <a href="testimonials.php">Read more</a>.
<br><br><code>Hector Wills, PhD.</code> Former Adjunct faculty PE Department.
<a target="external" rel="nofollow" href="https://www.mines.edu/">Colorado School of Mines</a>, 
Colorado, USA.∎

<hr width="100%">

2013 July: "I would also like to say that this program is amazing.
I spent full days looking for a <a href="logLAS.php">LAS reader</a> and GeolOil
prevailed with a truly outstanding product."
<br><br><code>Marden Wark. Petroleum Geoscientist.</code> NSW Government,
<a target="external" rel="nofollow" href="http://www.trade.nsw.gov.au">Department of Trade and Investment</a>, 
Australia.∎
</div>
</div>
</p>

<br>

<div class="listb">

<p class="center">
<a href="petroCutoffs.php">
<img class="w0032" src="Images/trophy_032x032.png" class="imgBright" width=32 height=32 border=0 align=botom alt="Trophy"></a>
<i>Our article <a href="petroCutoffs.php">How to calculate Petrophysicals Cutoffs</a>
has inspired or influenced the year 2019 multi-national European Patent <b>EP 31752674 A4 20180418</b>
</i>
</p>

<br><br>

<p class="centerFull">
<a href="logLAS_displayer.php">
<img src="Images/mainWebLog.gif" class="w0311 imgShadow" border="0" alt="GeolOil LAS well log interpretation and displayer application">
</a>
</p>

<p class="center">
<dfn>
A well log interpreted and displayed on GeolOil
</dfn>
</p>

<br>

<p>
Our user friendly LAS well logs <a href="logLAS_editor.php">reader, viewer, and editor</a>,
allows to <a href=logLAS_displayer.php>plot log curves</a> immediately, achieving a top quality display.
Our <a href="multi-well-work-flows.php">multi-well</a> work-flow of
<a href="logLAS_functions.php">sequential petrophysical functions</a> computations approach, allows to immediately
change any parameter (constant or a curve), and update all the petrophysical analysis interpretation to be re-computed
with a single click. Our <a href="petroSummaries.php">log upscaler</a> computes net-pay, petrophysical cutoffs,
water saturation, and more.
</p>
</div>

<br>

<p class="centerFull">
<a href="logLAS_editor.php">
<img src="Images/LAS_Editor.gif" class="w0311 imgShadow" border="0" alt="GeolOil LAS well log interpretation and displayer application">
</a>
</p>

<p class="center">
<dfn>
GeolOil fully featured LAS editor
</dfn>
</p>

<br>

<p>
GeolOil is a stable, finely-tuned large software package with 157,225 lines of
<a href="releases.php">source code</a> in 189 classes
designed to run seamlessly on the platforms Windows PC, Apple MacOS Macintosh, and Linux.
<a href="downloads.php">Download it today!</a>.
</p>

















</div>  <!-- text -->

<br><br>

<p class="center">

<? include 'preloadImages.html'; ?>
<? include 'bottomBar-Responsive.html'; ?>

<br>

<dfn>
GeolOil LLC<br>
6959 Isabell St.<br>
Arvada, CO 80007. USA
</dfn>
</p>

<br>

</div>  <!-- content -->

</body>
</html>
